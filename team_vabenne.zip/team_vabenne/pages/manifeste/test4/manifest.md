---
title: Dancing Queen
year: 1798
blub: hallo
author:
    firstname: Klettis
    lastname: Zorba
    bibname: 'Daguerre, Luis'
    fullname: 'Luis Daguerre'
beschreibung: true
vita: true
bibliographie: true
links: true
bilder: true
transkriptionen: true
content:
    items: '@self.children'
    order:
        custom:
            - beschreibung
            - vita
            - bibliographie
            - links
            - bilder
            - transkriptionen
---

hallo



