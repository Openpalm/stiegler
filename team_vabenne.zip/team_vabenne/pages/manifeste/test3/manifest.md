---
title: Deine Mutta
year: 1902
blub: hallo
author:
    firstname: Philipp
    lastname: Volker
    bibname: 'Volker, Phillipp'
    fullname: 'Philipp Volker'
beschreibung: true
vita: true
bibliographie: true
links: true
bilder: true
transkriptionen: true
content:
    items: '@self.children'
    order:
        custom:
            - beschreibung
            - vita
            - bibliographie
            - links
            - bilder
            - transkriptionen
---

hallo



