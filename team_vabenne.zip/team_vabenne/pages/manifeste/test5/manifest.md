---
title: Zorbaaa
year: 1538
blub: hallo
author:
    firstname: Martin
    lastname: Luther
    bibname: 'Daguerre, Luis'
    fullname: 'Luis Daguerre'
beschreibung: true
vita: true
bibliographie: true
links: true
bilder: true
transkriptionen: true
content:
    items: '@self.children'
    order:
        custom:
            - beschreibung
            - vita
            - bibliographie
            - links
            - bilder
            - transkriptionen
---

hallo



