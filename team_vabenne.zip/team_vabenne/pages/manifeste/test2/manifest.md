---
title: Meine Eier
author:
    firstname: Richard
    lastname: Lionheart
    bibname: 'Lionherat, Richard'
    fullname: 'Richard Lionheart'
year: 1273
beschreibung: true
vita: true
bibliographie: true
links: true
bilder: true
transkriptionen: true
content:
    items: '@self.children'
    order:
        custom:
            - beschreibung
            - vita
            - bibliographie
            - links
            - bilder
            - transkriptionen
---

hallo



