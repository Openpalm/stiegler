---
title: Daguerrotype
author: 
	firstname: Luis
	lastname: Daguerre
	bibname: Daguerre, Luis
	fullname: Luis Daguerre
year: 1838
transkriptionen: false
content:
    items: @self.children
    order:
        custom:
            - beschreibung
            - vita
            - bibliographie
            - links
            - bilder
            - transkriptionen
---




