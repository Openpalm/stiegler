---
title: Beschreibung
number: 1
---

Im Vorwort zu *Wundergarten der Natur (1932)* äußert sich Blossfeldt erstmals zu seinen Fotografien. Er meint, dass die elementare Inspirationsquelle der Kunst sowie der Technik in der Natur zu suchen sei. Der Formenreichtum und zweckorientierte Aufbau der Natur kann Blossfeldt zufolge an der Pflanze am deutlichsten nachvollzogen werden. Mittels der Kamera soll die Schönheit und künstlerisch-technische Vollkommenheit der Natur im Bild festgehalten werden. Blossfeldt erstellt seine „Pflanzenurkunden“ in der Hoffnung, dass sie dazu beitragen, eine allgemeine Sensibilisierung für die Vorbildhaftigkeit der tst zu generieren.
