---
title: Links
---


Historique et description des procédés du Daguerréotype et du Diorama, par Daguerre, Peintre, inventeur du Diorama, officier de la Légion-d’Honneur, membre de plusieurs Académies, etc.:
• http://books.google.de/books?id=tas-F3h7OFUC&printsec=frontcover&hl=de&source=gbs_ge_summary_r&cad=0#v=onepage&q&f=false

Videoanimation der Daguerreotypie – Hochschule für Gestaltung Mannheim:
• http://www.gestaltung.hs-mannheim.de/designwiki/previews/quicktime/index.php?id=4172&width=400&height=372&keepThis=true&TB_iframe=true

Daguerreian Society mit ausgewählten weiterführenden Links:
• http://daguerre.org/

Archiv mit Texten zur Daguerrotypie:
• http://daguerreotypearchive.org/index.html

Daguerreotype Gallery mit Erklärungen zum Verfahren und zu dessen Geschichte:
• http://www.daguerreotype-gallery.de/index.html

Englische Übersetzung des Flugblatts in Image, The Journal Of The George Eastman House, Nummer 1, März 1959: • http://image.eastmanhouse.org/files/GEH_1959_08_01.pdf 