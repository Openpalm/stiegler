---
title: Vita
---

**1787**
Geboren in Cormeilles-en-Parisis und aufgewachsen in Orléans

**1810**
Heirat mit Louise Georgina Arrowsmith und wird Dekorationsmaler mit Spezialisierung auf Panoramen

**1814**
Ausstellung im Pariser Salon

**1816**
führender Bühnenmaler im Théâtre de l’Ambigo-Comique im dritten Bezirk des Boulevard du Temple, später arbeitete er auch für die Pariser Oper 1819 Installation einer großen Camera Obscura im Parc de Belleville

**1821**
Eröffnet zusammen mit Charles Marie Bouton das erste Diorama in Paris

**Ab 1824**
Beschäftigung mit der Fixierung von Bildern der Camera Obscura

**Ab 1829**
Zusammenarbeit mit Joseph Nicéphore Niépce, der ebenfalls nach einem Verfahren der Fixierung sucht

**1837**
Entstehung der ältesten erhaltenen Daguerreotypie (Stillleben in Daguerres Atelier)

**13. Juni 1837**
Vertrag zwischen Daguerre und Isidore Niépce bezüglich der Veröffentlichung des von Nicéphore Niépce erfundenen und von Daguerre weiterentwickelten Verfahrens

**1839**
Vorstellung und offizielle Bekanntgabe von Daguerres Resultaten in der Akademie der Wissenschaften, Aufkauf des Verfahrens durch die französische Regierung

**7. Januar 1839**
Arago stellt die Daguerreotypie der Akademie der Wissenschaft vor

**Juli 1839**
Vorstellung des Verfahrens von Daguerre im la Chambre des députés mit Ausstellung einzelner Daguerreotypien

**1. Juni 1839**
reicht Daguerre trotz seiner Verhandlungen mit dem französischen Staat Antrag auf Patentierung seines Verfahrens in England, Wales und sämtlichen Kronkolonien ein 14. August 1839 Bewilligung von Daguerres Antrag auf Patentierung 22. Juni 1839 Unterzeichnung eines Vertrags zur Herstellung und Verkauf von Daguerreotyp-Apparaten zwischen Daguerre, Isidore Niépce, A. Giroux und Cie.

**25. August 1839**
öffentliche Ausstellung der Daguerreotypie in Wien unter Ferdinand I. 1841 Daguerre entwickelt die Daguerreotypie weiter, nun kann er auch bewegte Objekte in weniger als einer Sekunde einfangen

**Februar 1844**
Arago eröffnet, dass es Daguerre geschafft habe, die Belichtung auf weniger als ein Tausendstel einer Sekunde zu reduzieren

**1851**
stirbt in der Nähe von Paris