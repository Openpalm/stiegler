---
title: Bibliographie

---

Primärliteratur

– Historique et description des procédés du Daguerréotype et du Diorama, par Daguerre, Peintre, inventeur du Diorama, officier de la Légion-d’Honneur, membre de plusieurs Académies, etc., Paris 1839. [http://books.google.de/books?id=tas-F3h7OFUC&printsec=frontcover&hl=de&source=gbs_ge_summary_r&cad=0#v=onepage&q&f=false]

– Nouveau moyen de préparer la couche sensible des plaques destinées à recevoir les images photographiques. Lettre à M. Arago, Paris 1844. [http://www.gutenberg.org/ebooks/16260]

Sekundärliteratur (Auswahl)

– Stephen C. Pinson: Speculating Daguerre: art and enterprise in the work of L. J. M. Daguerre, Chicago 2012.

– Helmut and Alison Gernsheim: L.J.M. Daguerre. The History of the Diorama and the Daguerreotype, London 1956 (revised edition 1968).

– R. Colson (ed.): Mémoires originaux des créateurs de la photographie. Nicéphore Niepce, Daguerre, Bayard, Talbot, Niepce de Saint-Victor, Poitevin, Paris 1898.

– Adrien Mentienne: La découverte de la photographie en 1839 – Description Du Procédé Faite Aux Chambres Législatives Par Daguerre (Inventeur), Paris 1892.

– Beaumont Newhall: An Historical and Descriptive Account of the Various Processes of the Daguerreotype and the Diorama by Daguerre, New York 1971.

Edition

– Steffen Siegel (Hg.): Neues Licht. Daguerre, Talbot und die Veröffentlichung der Fotografie im Jahr 1839, München 2014.
